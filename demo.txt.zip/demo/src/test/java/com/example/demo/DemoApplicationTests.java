package com.example.demo;

import org.junit.Test;


class DemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
